function Footer() {
  return (
    <div className="pt-10 mt-20 border-t-2 text-center">
      <h2 className="text-gray-500"> AI Trip Planner designed and created with ❤️ by Kumar, Rohan & Lalit. </h2>
    </div>
  );
}

export default Footer;
