import "./App.css";
// import Header from "./custom/Header";
import Hero from "./custom/Hero";

function App() {
  return <Hero />;
}

export default App;
